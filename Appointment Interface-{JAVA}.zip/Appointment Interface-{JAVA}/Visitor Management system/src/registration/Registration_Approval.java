package registration;

import model.VisitorDetails;

import java.sql.*;

//**********************************************************************************************************************

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

//**********************************************************************************************************************
public class Registration_Approval  //contains method to perform insertion into Visitor_details table
{
    public boolean Insertion(Connection con,VisitorDetails visitorDetails)throws SQLException    //method to perform insertion into Visitor_details table
    {
        try     // Try block to perform inserting into visitor table
        {
            String insertQuery = "INSERT INTO Visitor_details(visitor_name,visitor_email,mobile_number,visitor_age,visitor_gender)"
                    + "VALUES (?, ?, ?, ?, ?)";     //insert statement for sql with necessary columns

            //index values to insert the data
            PreparedStatement preparedStatement = con.prepareStatement(insertQuery);
            preparedStatement.setString(1, visitorDetails.getName());
            preparedStatement.setString(2, visitorDetails.getEmail());
            preparedStatement.setString(3, visitorDetails.getMobile());
            preparedStatement.setInt(4, visitorDetails.getAge());
            preparedStatement.setString(5, visitorDetails.getGender());

            //executing insert statement
            int insertion = preparedStatement.executeUpdate();

            //condition for insert statement execution
            return insertion > 0;
        }
        catch (SQLException e)
        {
            // Insertion into the table failed
            return false;
        }
        // if insertion fails, Visitor has to re-enter all the details
    }
}
//**********************************************************************************************************************

//**********************************************************************************************************************




