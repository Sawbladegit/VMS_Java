package util;

import service.BaseService;
import service.Homepage;
import service.RegistrationPhase;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Scanner;

public class Controller extends BaseService // contains registration details and driver code for whole application
{
    // Database Connection
    public static final String DB_URL = "jdbc:mysql://localhost:3306/VisitorManagement";
    public static final String USER = "root";
    public static final String PASSWORD = "Adityasai.21";

    public Controller(Connection con, Scanner sc) { // Constructor to initialize BaseService
        super(con, sc);
    }

    public Connection getConnection() throws ClassNotFoundException, SQLException {
        Class.forName("com.mysql.cj.jdbc.Driver");
        return DriverManager.getConnection(DB_URL, USER, PASSWORD);
    }

    // Methods
    static Scanner sc = new Scanner(System.in);
    static Connection con;

    public static void main(String[] args) {
        Controller controller = new Controller(con,sc);
        int choice;

        try {
            con = controller.getConnection(); // Establish the database connection
        } catch (ClassNotFoundException | SQLException e) {
            System.out.println("Error connecting to the database.");
            e.printStackTrace();
            return;
        }

        while (true) {
            Homepage.displayHomepage();
            System.out.println("Enter your choice (1/2/3): ");

            String input = sc.nextLine();
            try {
                choice = Integer.parseInt(input);
            } catch (NumberFormatException e) {
                System.out.println("Invalid input. Please enter a valid integer.");
                continue;
            }

            switch (choice) {
                case 1:
                    Homepage.displayAdminPage(con, sc);
                    break;
                case 2:
                    RegistrationPhase.performRegistration(con, sc);
                    break;
                case 3:
                    System.out.println("Exiting the Visitor Management System. Goodbye!");
                    try {
                        if (con != null && !con.isClosed()) {
                            con.close(); // Close the database connection before exiting
                        }
                    } catch (SQLException e) {
                        e.printStackTrace();
                    } finally {
                        sc.close(); // Close the scanner before exiting
                    }
                    return;
                default:
                    System.out.println("Invalid choice. Please enter 1, 2, or 3.");
            }
        }
    }
}
