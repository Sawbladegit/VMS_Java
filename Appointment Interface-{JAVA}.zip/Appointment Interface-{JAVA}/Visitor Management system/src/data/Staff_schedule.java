package data;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

//**********************************************************************************************************************
public class Staff_schedule {
    public static void displayStaffSchedule(Connection con, String staffName) {
        try {
            String query = "SELECT staff_name,schedule_dates,slot_A,slot_B FROM Staff_schedule WHERE staff_name = ?";
            try (PreparedStatement preparedStatement = con.prepareStatement(query)) {
                preparedStatement.setString(1, staffName);

                ResultSet rs = preparedStatement.executeQuery();
                if (rs.next()) {
                    System.out.println("\nSchedule for " + staffName + " Is Given Below." +
                            "\nPlease Select the date and an Empty slot {' 0 '} To Fix the Appointment.\n" +
                            "\n---------------------------------------------");
                    System.out.print("Staff Name   Dates       slot_A   slot_B" +
                            "\n---------------------------------------------");

                    do {
                        String staff = rs.getString("staff_name");
                        String date = rs.getString("schedule_dates");
                        String slot_A = rs.getString("slot_A");
                        String slot_B = rs.getString("slot_B");
                        System.out.println("\n" + staff + "\t" + date + "\t   " + slot_A + "\t   " + slot_B);
                    } while (rs.next());
                } else {
                    System.out.println("No schedule found for Staff: " + staffName);
                }
                System.out.println("---------------------------------------------");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static boolean book_slot(Connection con, String staffName, String date, String slot) {
        try {
            String query = "SELECT " + slot + " FROM Staff_schedule WHERE staff_name = ? AND schedule_dates = ?";
            try (PreparedStatement preparedStatement = con.prepareStatement(query)) {
                preparedStatement.setString(1, staffName);
                preparedStatement.setString(2, date);

                ResultSet rs = preparedStatement.executeQuery();
                if (rs.next()) {
                    int slotValue = rs.getInt(1);
                    if (slotValue == 0) {
                        // Slot is available, fix the appointment
                        String updateQuery = "UPDATE Staff_schedule SET " + slot + " = 1 WHERE staff_name = ? AND schedule_dates = ?";
                        try (PreparedStatement updateStatement = con.prepareStatement(updateQuery)) {
                            updateStatement.setString(1, staffName);
                            updateStatement.setString(2, date);
                            int rowsUpdated = updateStatement.executeUpdate();
                            if (rowsUpdated > 0) {
                                System.out.println("Your appointment with " + staffName + " is fixed on " + date + " in " + slot + "\n");
                            }
                        }
                        return true;
                    }
                } else {
                    System.out.println("No schedule found for Staff: " + staffName + " on " + date);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }
}
