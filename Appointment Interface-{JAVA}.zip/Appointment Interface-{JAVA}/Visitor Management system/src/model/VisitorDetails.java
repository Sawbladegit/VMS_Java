package model;

// Variables storage class for encapsulation
public class VisitorDetails {
    private String name; // variable for visitor name
    private String email;  // variable for visitor email
    private String mobile;  // variable for mobile number name
    private int age;      // variable for visitor age
    private String gender;   // variable for visitor gender

    // Constructor to initialize the visitor details which will be called by main class
    public VisitorDetails(String name, String email, String mobile, int age, String gender) {
        this.name = name;
        this.email = email;
        this.mobile = mobile;           // pointing variable from class to constructor
        this.age = age;
        this.gender = gender;
    }

    // Getters for the visitor details
    public String getName() {
        return name;                    // will return visitor name after initialization in main class
    }

    public String getEmail() {
        return email;                  // will return visitor email after initialization in main class
    }

    public String getMobile() {
        return mobile;                  // will return mobile number after initialization in main class
    }

    public int getAge() {
        return age;                     // will return visitor age after initialization in main class
    }

    public String getGender() {
        return gender;                  // will return visitor gender after initialization in main class
    }
}
