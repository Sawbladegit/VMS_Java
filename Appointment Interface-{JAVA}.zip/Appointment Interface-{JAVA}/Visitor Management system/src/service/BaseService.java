package service;
import java.sql.Connection;
import java.util.Scanner;


public class BaseService
{
    protected Connection con;
    protected Scanner sc;

    public BaseService(Connection con, Scanner sc)
    {
        this.con = con;
        this.sc = sc;
    }
}
