package service;

import model.VisitorDetails;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

//**********************************************************************************************************************
class AppointmentManagement {
    public static void insertAppointment(Connection con, VisitorDetails visitorDetails, String staffName, String appointmentDate, String appointmentSlot) {
        try {
            // Check if the appointment already exists
            if (verifyAppointment(con, visitorDetails.getEmail(), visitorDetails.getMobile())) {
                System.out.println("This appointment already exists!");
                return;
            }

            // SQL query to insert appointment
            String insertQuery = "INSERT INTO Appointment_status(visitor_name, visitor_email, mobile_number, staff_name, appointment_date, appointment_slot, status) " +
                    "VALUES (?, ?, ?, ?, ?, ?, 'APPROVED')";

            PreparedStatement pstmt = con.prepareStatement(insertQuery);
            // Set values for the parameters
            pstmt.setString(1, visitorDetails.getName());
            pstmt.setString(2, visitorDetails.getEmail());
            pstmt.setString(3, visitorDetails.getMobile());
            pstmt.setString(4, staffName);
            pstmt.setString(5, appointmentDate);
            pstmt.setString(6, appointmentSlot);

            // Execute the query
            int rowsInserted = pstmt.executeUpdate();
            if (rowsInserted > 0) {
                System.out.println("Appointment successfully fixed!");
            } else {
                System.out.println("Failed to fix appointment!");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void displayAppointments(Connection con) {
        try {
            String selectQuery = "SELECT * FROM Appointment_status";
            try (PreparedStatement preparedStatement = con.prepareStatement(selectQuery)) {
                ResultSet rs = preparedStatement.executeQuery();

                System.out.println("\n------------------- Appointments -----------------------------------");
                System.out.println("Visitor Name | Visitor Email | Mobile Number | Staff Name | Appointment Date | Appointment Slot | Status");
                System.out.println("---------------------------------------------------------------------------------------------");

                while (rs.next()) {
                    String visitorName = rs.getString("visitor_name");
                    String visitorEmail = rs.getString("visitor_email");
                    String mobileNumber = rs.getString("mobile_number");
                    String staffName = rs.getString("staff_name");
                    String appointmentDate = rs.getString("appointment_date");
                    String appointmentSlot = rs.getString("appointment_slot");
                    String status = rs.getString("status");

                    System.out.printf("%-13s | %-13s | %-13s | %-11s | %-16s | %-16s | %s\n",
                            visitorName, visitorEmail, mobileNumber, staffName, appointmentDate, appointmentSlot, status);
                    System.out.println("------------------------------------------------------------------------------------------");
                }

                System.out.println("\nPlease Display The given Email address and Phone number to Security for getting a gate pass\n");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static boolean verifyAppointment(Connection con, String visitorEmail, String mobileNumber) {
        try {
            String query = "SELECT * FROM Appointment_status WHERE visitor_email = ? AND mobile_number = ?";
            PreparedStatement pstmt = con.prepareStatement(query);
            pstmt.setString(1, visitorEmail);
            pstmt.setString(2, mobileNumber);
            ResultSet rs = pstmt.executeQuery();
            return rs.next(); // If the appointment exists, return true; otherwise, return false.
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

}
