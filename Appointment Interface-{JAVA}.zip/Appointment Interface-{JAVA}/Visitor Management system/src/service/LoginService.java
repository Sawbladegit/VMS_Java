package service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

class LoginService {
    public static boolean validateLogin(Connection con, int userId, String password) throws SQLException {
        String select_query = "SELECT * FROM Login_details WHERE visitor_ID = ? AND visitor_password = ?";

        try (PreparedStatement preparedStatement = con.prepareStatement(select_query)) {
            preparedStatement.setInt(1, userId);
            preparedStatement.setString(2, password);

            ResultSet rs = preparedStatement.executeQuery();
            return rs.next(); // Return true if a matching record is found, else false
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false; // Return false in case of any error or no matching record found
    }
}
