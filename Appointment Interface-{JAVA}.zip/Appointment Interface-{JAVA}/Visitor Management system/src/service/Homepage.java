package service;

import java.sql.Connection;
import java.util.Scanner;

//**********************************************************************************************************************
public class Homepage extends BaseService {

    public Homepage(Connection con, Scanner sc) { // Constructor to initialize BaseService
        super(con, sc);
    }
    Scanner sc = new Scanner(System.in);

    public static void displayHomepage() {
        System.out.println("Welcome to KMIT Visitor Management System!");
        System.out.println("Please Select An Option Suitable For You!");
        System.out.println("1. Admin");
        System.out.println("2. Visitor");
        System.out.println("3. Exit");
    }

    public static void displayAdminPage(Connection con, Scanner sc) {
        while (true) {
            System.out.println("\nAdmin Page:");
            System.out.println("1. Display Staff Members Schedule");
            System.out.println("2. Display Registered Appointments");
            System.out.println("3. Display Past Approved Appointments");
            System.out.println("4. Go back to homepage");
            System.out.println("Enter your choice (1/2/3/4): ");

            int admin_choice;

            try {
                admin_choice = Integer.parseInt(sc.nextLine());
            } catch (NumberFormatException e) {
                System.out.println("Invalid input. Please enter a valid integer.");
                continue;
            }

            switch (admin_choice) {
                case 1:
                    AdminPage.displayStaffScheduleData(con);
                    break;
                case 2:
                    AdminPage.displayAppointmentStatusData(con);
                    break;
                case 3:
                    System.out.println("history");
                    break;
                case 4:
                    System.out.println("Going back to the homepage.");
                    return;
                default:
                    System.out.println("Invalid choice. Please enter 1, 2, 3, or 4.");
            }
        }
    }
}
