package service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

class Login_Generation {
    public void Login_details(Connection con) throws SQLException {
        String select_query = "SELECT * FROM Login_details ORDER BY RAND() LIMIT 1";

        try (PreparedStatement preparedStatement = con.prepareStatement(select_query)) {
            ResultSet rs = preparedStatement.executeQuery();

            while (rs.next()) {
                int UserID = rs.getInt("visitor_ID");
                String Password = rs.getString("visitor_password");
                System.out.println("\n-> UserId: " + UserID + "\n->Password: " + Password);
            }
            rs.close();
        } catch (SQLException e) {
            System.out.println("");
        }
    }
}
