package service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

//**************************************************************************************************************
class AdminPage {
    public static void displayStaffScheduleData(Connection con) {
        try {
            String selectQuery = "SELECT * FROM Staff_schedule";
            try (PreparedStatement preparedStatement = con.prepareStatement(selectQuery)) {
                ResultSet rs = preparedStatement.executeQuery();

                System.out.println("\n------------------- Staff Schedule Data --------------------------------");
                System.out.println("Staff Name | Dates       | slot_A | slot_B");
                System.out.println("---------------------------------------------------------------");

                while (rs.next()) {
                    String staffName = rs.getString("staff_name");
                    String date = rs.getString("schedule_dates");
                    int slotA = rs.getInt("slot_A");
                    int slotB = rs.getInt("slot_B");

                    System.out.printf("%-11s | %-11s | %-6s | %-6s\n", staffName, date, slotA, slotB);
                    System.out.println("---------------------------------------------------------------");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void displayAppointmentStatusData(Connection con) {
        try {
            String selectQuery = "SELECT * FROM Appointment_status";
            try (PreparedStatement preparedStatement = con.prepareStatement(selectQuery)) {
                ResultSet rs = preparedStatement.executeQuery();

                System.out.println("\n------------------- Appointment Status Data -----------------------------------");
                System.out.println("Visitor Name | Visitor Email | Mobile Number | Staff Name | Appointment Date | Appointment Slot | Status");
                System.out.println("--------------------------------------------------------------------------------");

                while (rs.next()) {
                    String visitorName = rs.getString("visitor_name");
                    String visitorEmail = rs.getString("visitor_email");
                    String mobileNumber = rs.getString("mobile_number");
                    String staffName = rs.getString("staff_name");
                    String appointmentDate = rs.getString("appointment_date");
                    String appointmentSlot = rs.getString("appointment_slot");
                    String status = rs.getString("status");

                    System.out.printf("%-13s | %-13s | %-13s | %-11s | %-16s | %-16s | %s\n",
                            visitorName, visitorEmail, mobileNumber, staffName, appointmentDate, appointmentSlot, status);
                    System.out.println("-------------------------------------------------------------------------------");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
/*
    public static void displayAppointmentHistoryData(Connection con) {
        try {
            String selectQuery = "SELECT * FROM Appointment_history";
            try (PreparedStatement preparedStatement = con.prepareStatement(selectQuery)) {
                ResultSet rs = preparedStatement.executeQuery();

                System.out.println("\n------------------- Appointment History Data -----------------------------------");
                System.out.println("Visitor Name | Visitor Email | Mobile Number | Staff Name | Appointment Date | Appointment Slot");
                System.out.println("--------------------------------------------------------------------------------");

                while (rs.next()) {
                    String visitorName = rs.getString("visitor_name");
                    String visitorEmail = rs.getString("visitor_email");
                    String mobileNumber = rs.getString("mobile_number");
                    String staffName = rs.getString("staff_name");
                    String appointmentDate = rs.getString("appointment_date");
                    String appointmentSlot = rs.getString("appointment_slot");

                    System.out.printf("%-13s | %-13s | %-13s | %-11s | %-16s | %-16s\n",
                            visitorName, visitorEmail, mobileNumber, staffName, appointmentDate, appointmentSlot);
                    System.out.println("-------------------------------------------------------------------------------");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
 */
}
