package service;

import model.VisitorDetails;
import data.Staff_schedule;
import registration.*;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.Scanner;

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
public class RegistrationPhase extends  BaseService
{
    public RegistrationPhase(Connection con, Scanner sc) { // Constructor to initialize BaseService
        super(con, sc);
    }
    public static void performRegistration(Connection con, Scanner sc) {
        try {
            int user_id;
            String pass;
            boolean loginSuccess = false;
            VisitorDetails visitorDetails;

            while (true) {
                // Taking Registration details from visitor
                System.out.println("--------------------------------------------------------------" +
                        "\nRegistration Phase For Appointment" +
                        "\n----------------------------------------------------------" +
                        "\nHi Visitor! Please Enter Requested Details To Register For An Appointment.");   // Welcome Message

                System.out.println("\n1)Enter Your Name { Only Alphabets From a-z (or) A-Z Or Combination Of Both }: "); //Visitor Name input
                String Visitor_Name = sc.nextLine();

                System.out.println("2)Enter Your Email ID { Should be in format of 'abc123@gmail.com' }: ");    //Visitor Email input
                String Visitor_Email = sc.nextLine();

                System.out.println("3)Enter Your Mobile Number { Should Contain Only Digits from 0-9 only }: "); //Visitor Mobile number input
                String Mobile_Number = sc.nextLine();

                System.out.println("4)Enter Your Age: ");
                int Visitor_age = sc.nextInt();
                sc.nextLine();
                if (Visitor_age < 18)                                       // Visitor Age input And Check
                {
                    System.out.println("Age must be 18 or above. You Aren't Authorized To request An Appointment.");  // Visitor age Check
                    System.exit(0);
                }

                System.out.println("Enter Your Gender: ");
                String Visitor_Gender = sc.next();// Visitor Gender Input
                sc.nextLine();

                visitorDetails = new VisitorDetails(Visitor_Name, Visitor_Email, Mobile_Number, Visitor_age, Visitor_Gender);

                Registration_Approval insert = new Registration_Approval();
                boolean insertionSuccessful = insert.Insertion(con, visitorDetails);

                if (insertionSuccessful) {
                    System.out.println("----------------------------------------------" +
                            "\nYour Registration Has Been Recorded!" +
                            "\n----------------------------------------------\n" +
                            "\nOur Portal Will Generate a UserId And Password, Use It To Login Into Your Account");
                    Login_Generation select = new Login_Generation();
                    select.Login_details(con);
                    break;
                } else {
                    System.out.println("Failed! Please Re-Enter The Data You Have Given Through Our Given References.");
                }
            }
            while (!loginSuccess) {
                System.out.println("--------------------------------------------------------------" +
                        "\nAppointment Slot Booking Phase" +
                        "\n----------------------------------------------------------" +
                        "\nHi Visitor! Please Enter Requested Details To Fix An Appointment");
                System.out.println("\nEnter UserID Allotted To You:");
                user_id = Integer.parseInt(sc.nextLine());
                System.out.println("Enter Password Allotted To You:");
                pass = sc.nextLine();

                if (LoginService.validateLogin(con, user_id, pass)) {
                    loginSuccess = true;
                    System.out.println("Login successful! User ID and password matched.");
                } else {
                    System.out.println("Login failed! User ID or password does not match.");
                }
            }
            System.out.println("\nEnter Staff Name You Want TO Set An Appointment With: \n" +
                    "\nAvailable Staff Members are: 'Mr.Narasimlu','Mrs.Aparna','Mrs.Priyanka','Mr.Anil','Mr.Maheshwar Dutta'");
            String staff_name = sc.nextLine();

            // Display the schedule of the specified staff_name
            Staff_schedule.displayStaffSchedule(con, staff_name);

            System.out.println("\nEnter Date For Appointment { Format Must Be In 'YYYY-MM-DD' }: ");
            String date = sc.nextLine();

            boolean slotPicked = false;
            String pickedSlot = "";

            while (!slotPicked) {
                System.out.println("Enter Slot Name Display In Above Schedule { slot_A (or) slot_B }: ");
                pickedSlot = sc.nextLine();

                if (pickedSlot.equals("slot_A") || pickedSlot.equals("slot_B")) {
                    slotPicked = true;
                } else {
                    System.out.println("Invalid slot. Please re-pick a slot marked as ' 0 '.");
                }
            }

            boolean appointmentFixed = Staff_schedule.book_slot(con, staff_name, date, pickedSlot);

            if (appointmentFixed) {
                // Show appointment status
                Staff_schedule.book_slot(con, staff_name, date, pickedSlot);

                // Insert appointment details
                AppointmentManagement.insertAppointment(con, visitorDetails, staff_name, date, pickedSlot);

                //display appointment details
                AppointmentManagement.displayAppointments(con);
            }
            System.out.println("--------------------------------------------------------------" +
                    "\nSecurity Check Phase For Appointment Verification" +
                    "\n----------------------------------------------------------" +
                    "\nHi Visitor! Please Enter Requested Details To Verify Your Appointment.");
            System.out.println("\nProvide Your Email: ");
            String Email = sc.nextLine();
            System.out.println("\nProvide Phone Number");
            String phone = sc.nextLine();

            boolean isAppointmentVerified = AppointmentManagement.verifyAppointment(con, Email, phone);

            if (isAppointmentVerified) {
                System.out.println("Appointment Verified! Gate Pass Allotted.\n");
            } else {
                System.out.println("Appointment not found or verification failed.");
            }
        } catch (SQLException s) {
            System.out.println("Error occurred while performing database operation: " + s.getMessage());
            s.printStackTrace();
        }
    }
}
